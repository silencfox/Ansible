.. _ansible_collections.vmware.vmware_rest.docsite.vmware_rest_appliance_services:

******************
Services managment
******************

Handle your VCSA services with Ansible
======================================

You can use Ansible to control the VCSA services. To get a view of all the known services, you can use the appliance_services_info module:

