*************************************************
vmware.vmware_rest: Ansible Collection for VMware
*************************************************

.. toctree::
   :maxdepth: 1
   :caption: vmware.vmware_rest documentation

   guide_vmware_rest
